/*==================================================
 *  Common localization strings
 *==================================================
 */

Timeline.strings["en"] = {
    wikiLinkLabel:  "Discuss"
};

