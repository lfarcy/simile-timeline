/** @ignore */
function hide(file) {
}

/*
[
    {
        symbols: [],
        overview: {
            doc: { tags: [] },
            returns: [],
            type: "",
            properties: [],
            isa: "FILE",
            desc: "No overview provided.",
            alias: "examples/data/ignore.js",
            memberof: "",
            params: [],
            methods: [],
            name: "examples/data/ignore.js"
        }
    }
]
*/