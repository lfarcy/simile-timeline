// nested functions

/** The layout object; */
function Layout(){
	this.init = function() {}
	
	/** an element of the layout */
	this.Element = function(elName) {
		this.expand = function() {
			
		};
	};
	this.Canvas = function(top, left, width, height) {
		this.initiated = true;
	}
	function rotate() {
	
	}
}