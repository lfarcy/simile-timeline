/*==================================================
 *  Common localization strings
 *==================================================
 */

Timeline.strings["cs"] = {
    wikiLinkLabel:  "Diskuze"
};

